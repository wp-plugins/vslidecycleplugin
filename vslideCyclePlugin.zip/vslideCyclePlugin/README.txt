=== vslideCyclePlugin ===

Contributors: Vinicius Gomes

Donate link: http://viniwp.wordpress.com


Requires at least: 3.0
Last Version Wordpress

Tested up to: 3.2.1

Stable tag: 1.0


Tags:
slide,cycle,plugin,wordpress,slideshow,vslidecycle,bannershow,bannerandom,

== Description == 

This plugin make a slide using jQuery Cycle

== Installation ==
   1. Upload vslideCycle folder to the /wp-content/plugins/ directory
   2. Activate the plugin through the 'Plugins' menu in WordPress
   3. You can add a widget to your website or use [vslidecycleplugin] syntax inside pages where you want it to appear.

== Frequently Asked Questions ==

= none.

== Upgrade Notice ==

1.0 New Version.

== Screenshots ==

No screenshots available

== Changelog ==

= 1.0 =
* First version
